package oOps_assgnment;

public class Matrix {
    private int[][] matrix;

    public Matrix(int rows, int cols) {
        this.matrix = new int[rows][cols];
    }

  
    public void fillMatrix(int[][] mat) {
        int rows = matrix.length;
        int cols = matrix[0].length;

        if (mat.length != rows || mat[0].length != cols) {
            throw new IllegalArgumentException("Enter mat dimensions do not match matrix dimensions ");
        }

        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < cols; j++) {
                matrix[i][j] = mat[i][j];
            }
        }
    }

    // Method to display the matrix
    public void displayMatrix() {
        int rows = matrix.length;
        int cols = matrix[0].length;

        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < cols; j++) {
                System.out.print(matrix[i][j] + " ");
            }
            System.out.println();
        }
    }

    public static void main(String[] args) {
        Matrix mat = new Matrix(3, 3);
        int[][] value = { { 6, 6, 3 }, { 9, 4, 7 }, { 3, 4, 3 } };
        mat.fillMatrix(value);
        mat.displayMatrix();
    }
}
