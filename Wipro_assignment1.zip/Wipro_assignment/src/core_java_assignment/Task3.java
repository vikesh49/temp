package core_java_assignment;

import java.util.*;

public class Task3 {
public static void main(String[] args) {
	Scanner sc=new Scanner(System.in);
	System.out.println("Enter a number to check for prime");
	int num=sc.nextInt();
	int sq=(int)Math.sqrt(num);
	int L=0;
	for(int i=2;i<=sq;i++) {
		if(num%i==0)
			L=1;
	}
	if(L==0)
		System.out.println("Number is prime");
	else
		System.out.println("Number is not prime");
	
}
}
