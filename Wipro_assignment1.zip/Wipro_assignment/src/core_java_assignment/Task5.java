package core_java_assignment;
import java.util.*;
public class Task5 {
public static void main(String[] args) {
	boolean temp=false;
	Scanner sc=new Scanner(System.in);
	System.out.println("Enter the size of array");
	int n=sc.nextInt();
	int[]arr=new int[n];
	System.out.println("Enter array elements");
	
	
	for(int i=0;i<n;i++)
	arr[i]=sc.nextInt();
	
	System.out.println("Enter target value");
	int targetsum=sc.nextInt();
	
	
	for(int i=0;i<n;i++) {
		for(int j=0;j<n;j++) {
			if(i!=j)
				if(arr[i]+arr[j]==targetsum)
					temp=true;
					
	}
		}
	if(temp)
		System.out.println("The target sum of two number exist");

else
	System.out.println("The target sum of two number  dose not exist");
}
}
