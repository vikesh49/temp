package core_java_assignment;

import java.util.Scanner;

public class Task8 {

	
	public static int[] NewArray(int arr[],int st,int end) {
	int ind=end-st+1;
	int[]newAr=new int[ind];
	for(int i=0;i<ind;i++) {
		newAr[i]=arr[i+st];
	}
	
	return newAr;
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the size of array");
		int n=sc.nextInt();
		int[]arr=new int[n];
		System.out.println("Enter array elements");
		
		for(int i=0;i<n;i++)
			arr[i]=sc.nextInt();
		
		
		System.out.println("Enter starting index of new Array");
		int start=sc.nextInt();
		
		System.out.println("Enter starting ending index of new Array");
		int end=sc.nextInt();
		
		int[]neArr=NewArray(arr,start,end);
		
		System.out.println("New  array elements are ");
		for(int i=0;i<end-start+1;i++)
			System.out.println(neArr[i]);
		
		
	}

}
