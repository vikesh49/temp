package core_java_assignment;
import java.util.*;
public class Task9 {
public static void main(String[] args) {
	Scanner sc=new Scanner(System.in);
	String st1=sc.nextLine();
	String st2=sc.nextLine();
	int len=sc.nextInt();
	String st3=st1+st2;
	String ans="";
	for(int i=0;i<st3.length();i++) {
		ans=st3.charAt(i)+ans;
	}
	int mid=st3.length()/2;
	if(st3.length()%2==0) {
		
		if(len%2==0) {
			int sta=mid-(len/2)-1;
			int end=mid+(len)/2;
			String res="";
			for(int i=sta;i<=end;i++) {
				res=res+st3.charAt(i);
			}
			System.out.println(res);
		
		}
		else {
			int sta=mid-(len/2);
		int end=mid+(len)/2;
		String res="";
		for(int i=sta;i<=end;i++) {
			res=res+st3.charAt(i);
		}
		System.out.println(res);
		}
	}
	
	else {
		if(len%2==0) {
			int sta=mid-(len/2)-1;
			int end=mid+(len)/2;
			String res="";
			for(int i=sta;i<=end;i++) {
				res=res+st3.charAt(i);
			}
			System.out.println(res);
		}
		else {
			int sta=mid-(len/2);
			int end=mid+(len)/2;
			String res="";
			for(int i=sta;i<=end;i++) {
				res=res+st3.charAt(i);
			}
			System.out.println(res);
		}
			
	}
	
}
}
